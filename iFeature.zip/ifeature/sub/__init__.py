# -*- coding: utf-8 -*-
"""
__title__ = '__init__.py'
__author__ = 'JieYuan'
__mtime__ = '2018/7/23'
"""
"""
初筛：方差、相关性、F检验、卡方、信息增益
细筛：SelectFromModel/FRECV
"""
from .FeatureSelector import FeatureSelector